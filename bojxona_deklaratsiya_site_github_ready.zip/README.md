# Bojxona Deklaratsiyasi Sayti

Ushbu loyiha O‘zbekiston Respublikasi Davlat Bojxona Qo‘mitasining bojxona yuk deklaratsiyasi (BJD) sahifasiga o‘xshash tarzda tayyorlangan.

## Ko‘rsatmalar

### Ishga tushurish:
1. Ushbu repozitoriyani klon qiling yoki ZIP faylni yuklab oling.
2. `index.html` faylni brauzerda oching.

### Fayl tuzilmasi:
```
/assets/
├── emblem_cs.png
├── Logo-tamozhni.png
├── backprint.png
└── pdf_1850.png
index.html
```

> Eslatma: `assets/` papkasidagi rasm fayllari bo‘sh (namuna sifatida). Ularni o‘zingiz haqiqiy fayllar bilan almashtiring.

## Live Preview
Siz ushbu loyihani GitHub Pages orqali ham ishga tushirishingiz mumkin:

1. GitHub’da yangi repozitoriy yarating.
2. Ushbu fayllarni yuklang.
3. Settings > Pages bo‘limida `main` branchdan `/root` papkani tanlang.
4. `https://yourusername.github.io/your-repo-name/` manzil orqali ochiladi.

---

**Muallif:** [Sizning Ismingiz]  
**Maqsad:** Ilmiy musobaqa uchun front-end loyihasi
